package com.viru.config; 

import com.viru.pojo.OrderStock;
import com.viru.pojo.OrderStockId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;
import java.util.List;

public interface OrderStocksRepository extends JpaRepository<OrderStock, OrderStockId> {
    
    Optional<OrderStock> findByUsernameAndStockid(String username, int stockid);
    
    List<OrderStock> findByUsername(String username);
    
    @Query("SELECT os.avgBuyPrice FROM OrderStock os WHERE os.username = :username AND os.stockid = :stockId")
    Double findAvgBuyPriceByUsernameAndStockid(@Param("username") String username, @Param("stockId") int stockId);
}