package com.viru.config; 

import com.viru.pojo.Stocks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface StocksRepository extends JpaRepository<Stocks, Integer> {
    
    @Query("SELECT s.stockid FROM Stocks s")
    List<Integer> findAllStockIds();
    
    @Modifying
    @Query("UPDATE Stocks s SET s.stockprice = :newPrice WHERE s.stockid = :stockId")
    int updateStockPrice(@Param("stockId") int stockId, @Param("newPrice") double newPrice);
}