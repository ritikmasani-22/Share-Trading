package com.viru.config;


import com.viru.daoimpl.StocksDaoImpl;

import org.springframework.context.annotation.Bean;

import com.viru.controller.PriceScheduler; 



public class SpringConfig {
 
 
 @Bean
 public PriceScheduler priceScheduler(StocksDaoImpl stocksDaoImpl) {
     PriceScheduler scheduler = new PriceScheduler(stocksDaoImpl);
     
    
     scheduler.startPriceUpdates(); 
     
     return scheduler;
 }
}
