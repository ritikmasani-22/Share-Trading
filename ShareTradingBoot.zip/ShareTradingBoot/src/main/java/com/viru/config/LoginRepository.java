package com.viru.config;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.viru.pojo.Login;

import jakarta.transaction.Transactional;


public interface LoginRepository extends CrudRepository<Login, String> {
	Optional<Login> findByUsernameAndPassword(String username, String password);

    List<Login> findByRole(String role);
    Optional<Login> findByUsername(String username);


    @Query("SELECT l.balance FROM Login l WHERE l.username = :username")
    Double findBalanceByUsername(@Param("username") String username);

    @Modifying
    @Query("UPDATE Login l SET l.balance = l.balance + :amount WHERE l.username = :username")
    int updateBalance(@Param("username") String username, @Param("amount") double amount);
    
    @Modifying
    @Transactional
    @Query("UPDATE Login l SET l.approved = true WHERE l.username = :username")
    int setApproved(@Param("username") String username);

    @Modifying
    @Transactional
    @Query("UPDATE Login l SET l.blocked = true WHERE l.username = :username")
    int setBlocked(@Param("username") String username);

    @Modifying
    @Transactional
    @Query("UPDATE Login l SET l.blocked = false WHERE l.username = :username")
    int setUnblocked(@Param("username") String username);
}
