package com.viru.controller; 

import com.viru.daoimpl.StocksDaoImpl;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import jakarta.annotation.PostConstruct; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Component; 

@Component 
public class PriceScheduler {
    
    private final StocksDaoImpl daoImpl;
    private final ScheduledExecutorService scheduler;
    
   
    @Autowired 
    public PriceScheduler(StocksDaoImpl daoImpl) {
        this.daoImpl = daoImpl;
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }
    
    @PostConstruct 
    public void startPriceUpdates() {
        
        final Runnable priceUpdaterTask = () -> {
            try {
              
                List<Integer> allStockIds = daoImpl.getstockids(); 
                
            
                for (Integer stockId : allStockIds) {
                    daoImpl.updateRandomPrice(stockId);
                }
            } catch (Exception e) {
                
                System.err.println("CRITICAL ERROR in scheduled task: " + e.getMessage());
              
            }
        };

       
        scheduler.scheduleAtFixedRate(
            priceUpdaterTask, 
            0, 
            1, 
            TimeUnit.SECONDS
        );
        
       
    }
    
    public void stopPriceUpdates() {
        scheduler.shutdown();
       System.out.println("--- Price scheduler stopped. ---");
    }
}