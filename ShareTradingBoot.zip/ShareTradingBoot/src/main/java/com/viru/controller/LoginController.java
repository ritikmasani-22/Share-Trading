package com.viru.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.viru.daoimpl.LoginDaoImpl;
import com.viru.daoimpl.StocksDaoImpl;
import com.viru.pojo.Login;
import com.viru.pojo.Stocks;

@Controller
public class LoginController {

    @Autowired
    private LoginDaoImpl daoimpl;

    @Autowired
    private OtpGeneretor gotp;

    @Autowired
    @Qualifier("otpMailService")
    private MailSender msend;

    @Autowired
    private StocksDaoImpl daoImpl2;

    private static final String SESSION_OTP = "genOtp";
    private static final String TEMP_USER = "tempUser";

    @GetMapping("/")
    public String indexpage(HttpServletRequest request) {
        return "signin";
    }

    @GetMapping("/signin")
    public String index(HttpServletRequest request) {
    	HttpSession session = request.getSession(false);
		if(session!=null)
			session.invalidate();
        return "signin";
    }

    @GetMapping("/signup")
    public String regpage() {
        return "signup";
    }

    @PostMapping("/addNewUser")
    public String handleNewUser(
            @RequestParam("b1") String op,
            @RequestParam("email") String email,
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            @RequestParam(value = "otp", required = false) String otpInput,
            Model m,
            HttpSession session) {

        Login l = new Login();
        l.setUsername(username);
        l.setEmail(email);
        l.setPassword(password);

        m.addAttribute("user", l);

        if (op.equals("SendOTP")) {
            String otp1 = gotp.OTPGenerator();
            session.setAttribute(SESSION_OTP, otp1);
            session.setAttribute(TEMP_USER, l);
            msend.sendOtp(email, otp1, session);

            m.addAttribute("msg", "OTP sent successfully! Please enter the code below. ✅");
            m.addAttribute("showOtpField", true);

            return "signup";
        }

        if (op.equals("Sign Up")) {
            String storedOtp = (String) session.getAttribute(SESSION_OTP);
            Login tempUser = (Login) session.getAttribute(TEMP_USER);

            if (storedOtp == null || tempUser == null) {
                m.addAttribute("msg", "Session expired or missing data. Please click 'Send OTP' first.");
                return "signup";
            }

            if (otpInput == null || !otpInput.equals(storedOtp)) {
                m.addAttribute("msg", "Invalid OTP. Please try again.");
                m.addAttribute("user", tempUser);
                m.addAttribute("showOtpField", true);
                return "signup";
            }

            if (daoimpl.addNewUser(tempUser)) {
                session.removeAttribute(SESSION_OTP);
                session.removeAttribute(TEMP_USER);

                m.addAttribute("msg", "Registration successful! Login here.");
                return "signin";
            } else {
                m.addAttribute("msg", "OTP verified, but registration failed in database.");
                m.addAttribute("user", tempUser);
                m.addAttribute("showOtpField", true);
                return "signup";
            }
        }

        m.addAttribute("msg", "Invalid request type.");
        return "signup";
    }

    @GetMapping("/managecustomer")
    public String manageCustomers(Model m, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            
            session = request.getSession(true);
        }

         List<Login> customerList = daoimpl.gellAllCustomer();
        session.setAttribute("customerList", customerList);
        m.addAttribute("customerList", customerList);

        return "managecutomer"; 
    }

   
    @PostMapping("/approveCustomer")
    public String approveCustomer(@RequestParam String username, RedirectAttributes ra) {
        boolean ok = daoimpl.approveUser(username);
        ra.addFlashAttribute("msg", ok ? "User approved: " + username : "User not found: " + username);
        return "redirect:/managecustomer";
    }

   
    @PostMapping("/toggleBlockCustomer")
    public String toggleBlockCustomer(@RequestParam String username,
                                      @RequestParam String action,
                                      RedirectAttributes ra) {
        boolean ok = false;
        String status;
        if ("block".equalsIgnoreCase(action)) {
            ok = daoimpl.blockUser(username);
            status = "blocked";
        } else {
            ok = daoimpl.unblockUser(username);
            status = "unblocked";
        }
        ra.addFlashAttribute("msg", ok ? username + " " + status : "User not found: " + username);
        return "redirect:/managecustomer";
    }

   
    @PostMapping("/deleteCustomer")
    public String deleteCustomer(@RequestParam("username") String username, RedirectAttributes ra) {
        boolean success = daoimpl.deleteCustomer(username);
        ra.addFlashAttribute("msg", success ? "Customer " + username + " successfully deleted." : "Failed to delete customer " + username + ".");
        return "redirect:/managecustomer";
    }

    @GetMapping("/adminallorders")
    public String adminAllOrders(Model m, HttpSession session) {
        if (session == null || session.getAttribute("username") == null) {
            m.addAttribute("msg", "Session expired. Please log in.");
            return "signin";
        }
        List<Stocks> allOrders = daoImpl2.getAll();
        m.addAttribute("allOrdersList", allOrders);

        return "adminallorders";
    }

    @PostMapping("/checkuser")
    public String checkuser(Login l, Model m, HttpServletRequest request) {

       
        Login logi = daoimpl.checkUser(l); 
        if (logi == null) {
          
            m.addAttribute("msg", "Invalid Username/Password");
            return "signin";
        }

        String role = logi.getRole() == null ? "" : logi.getRole();

       
        if ("Admin".equalsIgnoreCase(role)) {
          
            List<Stocks> lst = daoImpl2.getallstocks();
            m.addAttribute("allstock", lst);
            HttpSession session = request.getSession(true);
            session.setAttribute("allstock", lst);
            session.setAttribute("username", logi.getUsername());
            session.setAttribute("role", "Admin");
            m.addAttribute("msg", "Welcome to Admin Page");
            return "index";
        }

      
        if (logi.isBlocked()) {
          
            m.addAttribute("alertMsg", "You are blocked by admin. Please contact support.");
            return "signin";
        }

        if (!logi.isApproved()) {
           
            m.addAttribute("msg", "Your account is pending admin approval. Please wait.");
            return "signin";
        }

        
        List<Stocks> lst = daoImpl2.getallstocks();
        m.addAttribute("allstock", lst);
        HttpSession session = request.getSession(true);
        session.setAttribute("allstock", lst);
        session.setAttribute("username", logi.getUsername());
        session.setAttribute("role", "Customer");
        m.addAttribute("msg", "Welcome to Customer Page");
        return "customer";
    }

    }


