package com.viru.controller;


import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.viru.daoimpl.LoginDaoImpl;
import com.viru.daoimpl.StocksDaoImpl;
import com.viru.pojo.Stocks;

@Controller
public class StocksController {

	@Autowired
	public StocksDaoImpl daoimpl;
	
	@Autowired
	public LoginDaoImpl logindaoimpl;
	
	@GetMapping("/amdstocks")
	public String amdstockspage()
	{
		return "amdstocks";
	}
	@GetMapping("/delete")
	public String deletepage(Model m, HttpSession session)
	{
		List<Stocks> lst = daoimpl.getallstocks();
	      
        session.setAttribute("allstock", lst);
        m.addAttribute("allstock", lst);
        		return "delete";
	}
	@GetMapping("/updatestockpage")
	public String getUpdateStockPage(Model m) {
	   
	    List<Stocks> allStocks = daoimpl.getallstocks(); 
	    m.addAttribute("allStocksList", allStocks); 
	    return "update";
	}
	
	@GetMapping("/index")
	public String indexpage(Model m, HttpSession session) 
	{	    
         List<Stocks> lst = daoimpl.getallstocks();
      
        session.setAttribute("allstock", lst);
        m.addAttribute("allstock", lst);
        
         String username = (String) session.getAttribute("username");
        if (username != null) {
            Double currentBalance = logindaoimpl.getBalance(username);
            session.setAttribute("currentBalance", currentBalance);
            m.addAttribute("currentBalance", currentBalance);
        }
        
	    return "index";
	}
	@GetMapping("/customer")
	public String custmopage(Model m, HttpSession session) 
	{	    
         List<Stocks> lst = daoimpl.getallstocks();
      
        session.setAttribute("allstock", lst);
        m.addAttribute("allstock", lst);
        
         String username = (String) session.getAttribute("username");
        if (username != null) {
            Double currentBalance = logindaoimpl.getBalance(username);
            session.setAttribute("currentBalance", currentBalance);
            m.addAttribute("currentBalance", currentBalance);
        }
        
	    return "customer";
	}
	
	@GetMapping("/allorderstocks")
	public String allorderstocks(Model m,HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
	   if(session!=null)
	   {
		session.getAttribute("username");
	   }
	  session = request.getSession(true);
		String username = (String)session.getAttribute("username");
		List<Stocks> lst = daoimpl.getallorderstocks(username);
		for (Stocks sk : lst) {
			Stocks inventory = daoimpl.search(sk.getStockid());
			if(inventory != null) {
	            sk.setStockprice(inventory.getStockprice()); 
	        }
	        double buyPrice = daoimpl.getUserBuyPrice(username, sk.getStockid());
	        sk.setAvgBuyPrice(buyPrice); 
	    }
		session.setAttribute("userHoldings", lst);
		 m.addAttribute("allorder", lst);
		 Double currentBalance = (Double) session.getAttribute("currentBalance");
		    
		    if (currentBalance == null) {
		        currentBalance = logindaoimpl.getBalance(username);
		        session.setAttribute("currentBalance", currentBalance); 		    }
		   m.addAttribute("currentBalance", currentBalance);
		 
		 m.addAttribute("currentBalance", session.getAttribute("currentBalance"));
		    m.addAttribute("allstocks", daoimpl.getallstocks());
		  return "allstocks";
		}
	
	
	@GetMapping("/editstock")
	public String editStock(@RequestParam(value="stockid", required=false)Integer stockId, Model m) {
	    
	    List<Stocks> allStocks = daoimpl.getallstocks();
	    m.addAttribute("allStocksList", allStocks); 
	    Stocks stockToEdit = daoimpl.search(stockId);
	    
	    if (stockToEdit != null) {
	      
	        m.addAttribute("stockToEdit", stockToEdit);
	        m.addAttribute("msg", "Stock ID: " + stockId + " loaded successfully.");
	    } else {
	      
	        m.addAttribute("msg", "Error: Stock not found for ID " + stockId);
	    }
	    
	  
	    return "update"; 
	}
	
	@PostMapping("/stocksaction")
	public String stocksactionpage(@RequestParam(value="stockseize", required=false)Integer skseize,
			@RequestParam(value="stockid", required=false)Integer skid,
			@RequestParam(value="stockname", required=false)String skname,
			@RequestParam(value="stockprice", required=false)Double skprice, 
			@RequestParam("b1")String Op,
			Model m)throws Exception
	{
		Stocks sk = new Stocks();
	
		if(Op.equals("Add Stock"))
		{
			sk.setStockname(skname);
			sk.setStockprice(skprice);
			sk.setStockseize(skseize);
			
			if(daoimpl.addstoks(sk))
			{
				m.addAttribute("msg","Stock Added Succesfully");
				return "amdstocks";
			}
			else
				m.addAttribute("msg","Stock not Added ");
		    	return "amdstocks";
				
		}
		if(Op.equals("Update Stock"))
		{
			sk.setStockid(skid);
			sk.setStockname(skname);
			sk.setStockprice(skprice);
			sk.setStockseize(skseize);
			if(daoimpl.updatestoks(sk))
			{
				m.addAttribute("msg","Stock Updated Succesfully");
				return "update";
			}
			
			else
				
				m.addAttribute("msg","Stock not Updated ");
		    	return "update";
				
		}
		else
		{
			sk.setStockid(skid);
			if(daoimpl.deletestoks(skid))
			{
				m.addAttribute("msg","Stock Deleted Succesfully");
				return "redirect:/delete";
			}
			else
				m.addAttribute("msg","Stock not Deleted ");
		    	return "delete";
				
		}
				
	}
    
	@PostMapping("/orderstocks")
	public String buysellstocks(@RequestParam("stockid")Integer skid, @RequestParam("a1")String Op,Model m,HttpServletRequest request)throws Exception
	
	{
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("username");
		Stocks sk = new Stocks();
		sk.setStockid(skid);
		sk.setUsername(username);
		Stocks s = daoimpl.search(skid);
		m.addAttribute("stocks",s);
		
		if(Op.equals("Buy")) {
			if(daoimpl.search(skid) != null)
				
			{
				return "buypage";
			}
			else
			{
				m.addAttribute("msg","Stocks could not be Buy ");
				return "customer";
			}
		}
		else 
		{
          if(daoimpl.search(skid) != null)
				
			{
				return "sellpage";
			}
			else
			{
				m.addAttribute("msg","Stocks could not be Buy ");
				return "customer";
			}
		}
		
		
	}
	@PostMapping("/stocksoppre")
	public String accaction(@RequestParam("seize")String seize,@RequestParam("stockprice")String stockprice,@RequestParam("stockid")Integer stockId,
			@RequestParam("b1")String op,HttpServletRequest request,Model m,RedirectAttributes redirectAttributes)
	{
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("username");
		int sz = Integer.parseInt(seize);
		String target="redirect:/allorderstocks";
		double price = Double.parseDouble(stockprice);
		
		Stocks inventoryStock = daoimpl.search(stockId);
		Stocks userHolding = daoimpl.getUserStockHolding(stockId, username);
				
		if (op.equals("Buy")) {
		   
		        double stockPrice = inventoryStock.getStockprice();
		        double totalCost = stockPrice * sz;
		        double currentBalance = logindaoimpl.getBalance(username); 
		        
		      
		        if (inventoryStock.getStockseize() < sz)
		        {
		        	redirectAttributes.addFlashAttribute("msg", "Buy failed. Only " + inventoryStock.getStockseize() + " shares available.");
		        } 
		        else if (currentBalance < totalCost) 
		        {
		        	redirectAttributes.addFlashAttribute("msg", "Purchase failed. Insufficient balance. Required: " + String.format("%.2f", totalCost));
		        } 
		        else 
		        {
		           
		            inventoryStock.setStockseize(inventoryStock.getStockseize() - sz);
		            boolean inventoryUpdated = daoimpl.updatestoks(inventoryStock); 
		            
		            boolean stockBought = daoimpl.buystocks(username, stockId, sz,price); 
		            
		            if (inventoryUpdated && stockBought) 
		            {
		                boolean balanceUpdated = logindaoimpl.updateBalance(username, -totalCost);
		                
		                if (balanceUpdated) 
		                {
		                    double newBalance = logindaoimpl.getBalance(username);
		                    session.setAttribute("currentBalance", newBalance); 
		                    
		                    redirectAttributes.addFlashAttribute("msg", "Success! Purchased " + sz + " shares of " + inventoryStock.getStockname() + ". New balance: " + String.format("%.2f", newBalance));
		                } 
		                else 
		                {
		                	redirectAttributes.addFlashAttribute("msg", "Purchase complete, but failed to deduct funds. Contact support.");
		                      }
		            } 
		            else {
		            	redirectAttributes.addFlashAttribute("msg", "Stock purchase failed at the database level.");
		            }
		        }
		        List<Stocks> updatedHoldings = daoimpl.getallorderstocks(username);
		        	for (Stocks sk : updatedHoldings) {
		         double buyPrice = daoimpl.getUserBuyPrice(username, sk.getStockid());
		         sk.setAvgBuyPrice(buyPrice); 
		     }
		        	session.setAttribute("userHoldings", updatedHoldings); 

		     m.addAttribute("allorder", updatedHoldings);
		    
		    m.addAttribute("currentBalance", session.getAttribute("currentBalance")); 
		    m.addAttribute("allstocks", daoimpl.getallstocks()); 
		    return target;
		}


		if (op.equals("Sell")) {
		   
		    Stocks marketStock = daoimpl.search(stockId);
		    
		    if (userHolding == null || userHolding.getStockseize() < sz) {
		    	redirectAttributes.addFlashAttribute("msg", "Sale failed. Not enough shares owned to sell " + sz + ".");
		    } 
		    else
		    {
		        double stockPrice = marketStock.getStockprice();
		        double totalEarnings = stockPrice * sz;
		        
		        marketStock.setStockseize(marketStock.getStockseize() + sz);
		        boolean inventoryUpdated = daoimpl.updatestoks(marketStock);
		        
		       
		        boolean stockSold = daoimpl.sellstocks(userHolding, sz); 
		        
		        if (inventoryUpdated && stockSold) 
		        {
		            
		            boolean balanceUpdated = logindaoimpl.updateBalance(username, totalEarnings);
		            
		            if (balanceUpdated) 
		            {
		             
		                double newBalance = logindaoimpl.getBalance(username);
		                session.setAttribute("currentBalance", newBalance); 
		                
		                redirectAttributes.addFlashAttribute("msg", "Success! Sold " + sz + " shares. Total return amount: " + String.format("%.2f", totalEarnings) + ". New balance: " + String.format("%.2f", newBalance));
		            } 
		            else 
		            {
		            	redirectAttributes.addFlashAttribute("msg", "Sale complete, but failed to add funds. Contact support.");
		            }
		        } else {
		        	redirectAttributes.addFlashAttribute("msg", "Sale failed at the transaction level.");
		        }
		    }
		    
		    
		    m.addAttribute("currentBalance", session.getAttribute("currentBalance")); 
		    m.addAttribute("allstocks", daoimpl.getallstocks()); 
		}
		    return target;
		}

	@PostMapping("/addfunds")
	public String addFundsAction(@RequestParam("amount") String amountStr, HttpServletRequest request, Model m,RedirectAttributes redirectAttributes) {
	    HttpSession session = request.getSession();
	    String username = (String) session.getAttribute("username");
	  
	    double amount = 0.0;
	        amount = Double.parseDouble(amountStr);
	   
	    if (amount > 0) {
	        boolean success = logindaoimpl.updateBalance(username, amount);
	        if (success) {
	        	double newBalance = logindaoimpl.getBalance(username);
	            session.setAttribute("currentBalance", newBalance);
	            redirectAttributes.addFlashAttribute("msg", "Successfully added " +  amount + " to your account.");
	        } else {
	        	redirectAttributes.addFlashAttribute("msg", "Failed to add amount. Database update failed.");
	        }
	    } else {
	    	redirectAttributes.addFlashAttribute("msg", "Amount must be greater than zero.");
	    }

	   
	    m.addAttribute("currentBalance", session.getAttribute("currentBalance")); 
	    m.addAttribute("allstocks", daoimpl.getallstocks()); 
	     return "redirect:/allorderstocks";
	}
	@GetMapping(value = "/prices", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Stocks> getPrices() {
	    List<Stocks> lst = daoimpl.getallstocks();
	    return lst;
	}
}








