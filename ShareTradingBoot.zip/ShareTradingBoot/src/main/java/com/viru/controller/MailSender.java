package com.viru.controller;

import java.util.Properties;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpSession;


import org.springframework.stereotype.Service;

@Service("otpMailService")
public class MailSender {
		public  void sendOtp(String toEmail, String otp, HttpSession session1) {
			
			String user=(String)session1.getAttribute("cName");
			final String fromEmail="virendrapatidar49682@gmail.com";
			final String password="ykowgyjzovxdfdte";
			
			Properties props=new Properties();
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			
			Session session=Session.getInstance(props, new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(fromEmail, password);
				}
			});
			
			try {
				Message message=new MimeMessage(session);
				message.setFrom(new InternetAddress(fromEmail));
				
				message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
				message.setRecipients(Message.RecipientType.CC, InternetAddress.parse("virendrapatidar49682@gmail.com"));
				
				message.setSubject("Your OTP Code for Verification");
				String msg = "<p>Hi <strong>" + user + "</strong>,</p>"
				        + "<p>We received a request to verify your identity. Please use the following One-Time Password (OTP) to complete your action:</p>"
				        + "<h2 style='color:blue;'>&#128272; Your OTP is: <strong>" + otp + "</strong></h2>"
				        + "<p>This OTP is valid for 5 minutes. <b>Do not share this code</b> with anyone for security reasons.</p>"
				        + "<p>If you did not initiate this request, please ignore this email or contact our support immediately.</p>"
				        + "<br><p>Thank you for choosing <strong>Your Company Name</strong>!</p>"
				        + "<p>Stay secure,<br>The Your Company Team</p>";

				message.setContent(msg, "text/html");
				Transport.send(message);
				
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}