package com.viru.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.viru.config.OrderStocksRepository;
import com.viru.config.StocksRepository;
import com.viru.dao.StocksDao;
import com.viru.pojo.OrderStock;
import com.viru.pojo.OrderStockId;
import com.viru.pojo.Stocks;

import jakarta.transaction.Transactional;

@Component
public class StocksDaoImpl  implements StocksDao{
	
	 private final LoginDaoImpl loginDaoImpl;
	
	
	StocksDaoImpl(LoginDaoImpl loginDaoImpl)
	{
		this.loginDaoImpl = loginDaoImpl;
	}
@Autowired
  private	StocksRepository stocksRepository;
	
@Autowired
private	OrderStocksRepository orderStockRepository;


	@Override
	public boolean addstoks(Stocks sk) {
		try
		{
			stocksRepository.save(sk);
			return true;
		}
		catch (Exception e) {
		e.printStackTrace();
		return false;
		}
	}

	@Override
	public boolean updatestoks(Stocks sk) {
		try
		{
			stocksRepository.save(sk);
			return true;
		}
		catch (Exception e) {
		e.printStackTrace();
		return false;
		}
	}

	@Override
	public boolean deletestoks(int skid) {
		try
		{
			stocksRepository.deleteById(skid);
			return true;
		}
		catch (Exception e) {
		e.printStackTrace();
		return false;
		}
	}

	@Override
	public Stocks search(int skid) {
		try
		{
			Optional<Stocks> sk = stocksRepository.findById(skid); 
			return sk.orElse(null);
		}
		catch (Exception e) {
		e.printStackTrace();
		return null;
		}
	}

	@Override
	public List<Stocks> getallstocks() {
	
		try
		{
		List<Stocks> lst =  stocksRepository.findAll();
		
			return lst;
		
		}
		catch (Exception e) {
		e.printStackTrace();
		return null;
		}
	}


	@Override
	public Stocks getUserStockHolding(int stockId, String username) {
	    try {
	      
	        Optional<OrderStock> holdingOptional = orderStockRepository.findByUsernameAndStockid(username, stockId);
	        
	       
	        if (holdingOptional.isPresent()) {
	            OrderStock holding = holdingOptional.get();
	            
	         
	            Stocks stockHolding = new Stocks(); 
	            stockHolding.setStockid(holding.getStockid());
	            stockHolding.setStockname(holding.getStockname());
	            stockHolding.setStockseize(holding.getQuantity()); 
	            stockHolding.setStockprice(holding.getCurrentStockPrice()); 
	            stockHolding.setUsername(holding.getUsername());
	            stockHolding.setAvgBuyPrice(holding.getAvgBuyPrice());
	            
	            return stockHolding;
	        }
	        
	       
	        return null;
	        
	    } catch (Exception e) {
	        
	        e.printStackTrace();
	        return null;
	    }		     
	}
	
	@Override
	@Transactional
	public boolean buystocks(String username, int stockId, int quantity,double price) {
	    try {
	        Optional<OrderStock> currentHoldingOptional = orderStockRepository.findByUsernameAndStockid(username, stockId);
	        Stocks inventory = search(stockId);
	        
	       
	        if (inventory == null) {
	            return false;
	        }

	        double currentStockPrice = inventory.getStockprice();

	        if (currentHoldingOptional.isPresent()) {
	            // --- UPDATE Logic --- 
	            OrderStock currentHolding = currentHoldingOptional.get();
	            int newQuantity = currentHolding.getQuantity() + quantity;
	            double newAvgBuyPrice = currentStockPrice;

	            currentHolding.setQuantity(newQuantity);
	            currentHolding.setAvgBuyPrice(newAvgBuyPrice);
	            orderStockRepository.save(currentHolding);
	            return true;
	            
	        } else {
	              
	            OrderStock newHolding = new OrderStock();
	            newHolding.setUsername(username);
	            newHolding.setStockid(stockId);
	            newHolding.setStockname(inventory.getStockname());
	            newHolding.setQuantity(quantity);
	            newHolding.setCurrentStockPrice(currentStockPrice);
	            newHolding.setAvgBuyPrice(currentStockPrice);

	            orderStockRepository.save(newHolding);
	            return true;
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	

	@Override
	@Transactional
	public boolean sellstocks(Stocks userHolding, int quantityToSell) {
	    try {
	       
	        Optional<OrderStock> holdingOptional = orderStockRepository.findByUsernameAndStockid(
	            userHolding.getUsername(), 
	            userHolding.getStockid());

	       
	        if (!holdingOptional.isPresent()) {
	            return false;
	        }
	        
	        OrderStock holding = holdingOptional.get();
	        int newQuantity = holding.getQuantity() - quantityToSell;

	        if (newQuantity > 0) {
	            
	            holding.setQuantity(newQuantity);
	            orderStockRepository.save(holding);
	            return true;
	            
	        } else if (newQuantity == 0) {
	            OrderStockId id = new OrderStockId();
	            id.setUsername(holding.getUsername());
	            id.setStockid(holding.getStockid());
	            
	            orderStockRepository.deleteById(id);
	            return true;
	        }
	        
	        return false;

	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}



	@Override
	public List<Stocks> getallorderstocks(String username) {
		try {
		    List<OrderStock> orderList = orderStockRepository.findByUsername(username);
		   
		    return orderList.stream().map(holding -> {
                Stocks sk = new Stocks();
                sk.setStockid(holding.getStockid());
                sk.setStockname(holding.getStockname());
                sk.setStockseize(holding.getQuantity());
                sk.setStockprice(holding.getCurrentStockPrice()); 
                sk.setUsername(holding.getUsername());
                sk.setAvgBuyPrice(holding.getAvgBuyPrice());
                return sk;
            }).collect(Collectors.toList());
		
		} catch (Exception e) {
		    e.printStackTrace();
		    return null;
		}
	}
	
	@Override
	public List<Stocks> getAll() {
		try {
		    List<OrderStock> allOrders = orderStockRepository.findAll();
		    
		    return allOrders.stream().map(holding -> {
                Stocks sk = new Stocks();
                sk.setStockid(holding.getStockid());
                sk.setStockname(holding.getStockname());
                sk.setStockseize(holding.getQuantity());
                sk.setStockprice(holding.getCurrentStockPrice()); 
                sk.setUsername(holding.getUsername());
                sk.setAvgBuyPrice(holding.getAvgBuyPrice());
                return sk;
            }).collect(Collectors.toList());
		
		} catch (Exception e) {
		    e.printStackTrace();
		    return null;
		}
	}


	@Override
	public double getUserBuyPrice(String username, int stockId) {
	    try {
	        Double avgPrice = orderStockRepository.findAvgBuyPriceByUsernameAndStockid(username, stockId);
	        
	        return (avgPrice != null) ? avgPrice : 0.0;
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	        return 0.0;
	    }
	}

	public List<Integer> getstockids() {
	    try {
	       
	        return stocksRepository.findAllStockIds();
	        
	    } catch (Exception e) {
	       
	        System.err.println("Error fetching stock IDs: " + e.getMessage());
	        
	        
	        return new ArrayList<>(); 
	    }
	}
	@Transactional
	public boolean updateRandomPrice(int stockId) {
	    try {
	       
	        Stocks stock = search(stockId);
	        if (stock == null) {
	            return false;
	        }

	        double currentPrice = stock.getStockprice();

	        double changePercent = (Math.random() * 0.01) - 0.003;
	        double newPrice = currentPrice * (1 + changePercent);
	        
	        newPrice = Math.round(newPrice * 100.0) / 100.0;

	       
	        if (newPrice < 1.0) {
	            newPrice = 1.0;
	        }

	      
	        int count = stocksRepository.updateStockPrice(stockId, newPrice);
	        
	        return count > 0;

	    } catch (Exception e) {
	       
	        return false;
	    }
	}
}