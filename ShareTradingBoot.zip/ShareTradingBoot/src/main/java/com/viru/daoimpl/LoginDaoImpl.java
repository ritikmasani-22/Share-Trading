package com.viru.daoimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.viru.config.LoginRepository;
import com.viru.dao.LoginDao;
import com.viru.pojo.Login;

import jakarta.transaction.Transactional;

@Service
public class LoginDaoImpl implements LoginDao {
	
	
	
	@Autowired

	private LoginRepository loginRepository;

	@Override
	public boolean addNewUser(Login l) {
		try
		{
			l.setRole("Customer");
		     loginRepository.save(l);
			return true;
		}
		catch (Exception e) {
		e.printStackTrace();
		return false;
		}
		
	}
	
    @Override
	public Login checkUser(Login l) {
    	try
		{
    		Optional<Login> log = loginRepository.findByUsernameAndPassword(l.getUsername(), l.getPassword());
		
			return log.orElse(null);
		}
		catch (Exception e) {
		e.printStackTrace();
		return null;
		}

	}

    @Transactional
	@Override
	public boolean updateBalance(String username, double amount) {
		try {
			int count = loginRepository.updateBalance(username, amount);	
			if(count>0)
				return true;
			else
				return false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public double getBalance(String username) {
        try {
            
        	Double balance = loginRepository.findBalanceByUsername(username);
        	
        	return balance;
        } catch (EmptyResultDataAccessException e) {
            
            return 0.0; 
        } catch (Exception e) {
            e.printStackTrace();
            return 0.0;
        }
    }

	@Override
	public List<Login> gellAllCustomer() {
   try {
	   List<Login> lst = loginRepository.findByRole("Customer");
       return lst;
	   
    } catch (Exception e) {
	return null;
    }		 

	}

	@Override
	public boolean deleteCustomer(String username) {
		try {
			loginRepository.deleteById(username);
            return true;
		} catch (Exception e) {
		
			return false;
		}
	}	
    
	 @Override
	    @Transactional
	    public boolean approveUser(String username) {
	        try {
	            int updated = 0;
	            try {
	                updated = loginRepository.setApproved(username);
	            } catch (Exception ex) {
	                // ignore, fallback
	            }
	            if (updated > 0) return true;

	            Optional<Login> opt = loginRepository.findByUsername(username);
	            if (opt.isPresent()) {
	                Login u = opt.get();
	                u.setApproved(true);
	                loginRepository.save(u);
	                return true;
	            }
	            return false;
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	    @Override
	    @Transactional
	    public boolean blockUser(String username) {
	        try {
	            int updated = 0;
	            try {
	                updated = loginRepository.setBlocked(username);
	            } catch (Exception ex) {
	                // ignore
	            }
	            if (updated > 0) return true;

	            Optional<Login> opt = loginRepository.findByUsername(username);
	            if (opt.isPresent()) {
	                Login u = opt.get();
	                u.setBlocked(true);
	                loginRepository.save(u);
	                return true;
	            }
	            return false;
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	    @Override
	    @Transactional
	    public boolean unblockUser(String username) {
	        try {
	            int updated = 0;
	            try {
	                updated = loginRepository.setUnblocked(username);
	            } catch (Exception ex) {
	                // ignore
	            }
	            if (updated > 0) return true;

	            Optional<Login> opt = loginRepository.findByUsername(username);
	            if (opt.isPresent()) {
	                Login u = opt.get();
	                u.setBlocked(false);
	                loginRepository.save(u);
	                return true;
	            }
	            return false;
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
	    
	   
	
	
}
