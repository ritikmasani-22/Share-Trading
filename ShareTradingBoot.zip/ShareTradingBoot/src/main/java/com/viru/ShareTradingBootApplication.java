package com.viru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShareTradingBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShareTradingBootApplication.class, args);
	}

}
