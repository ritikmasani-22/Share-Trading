package com.viru.dao;

import java.util.List;

import com.viru.pojo.Stocks;

public interface StocksDao {
	
	boolean addstoks(Stocks sk);
	boolean updatestoks(Stocks sk);
	boolean deletestoks(int skid);
	Stocks search(int skid);
	List<Stocks> getallstocks(); 
	Stocks getUserStockHolding(int stockId, String username);
	boolean buystocks(String username, int stockId, int quantity,double price);
	boolean sellstocks(Stocks userHolding, int quantityToSell);
	List<Stocks> getallorderstocks(String username ); 
	double getUserBuyPrice(String username, int stockId);
	List<Stocks> getAll();
}
