package com.viru.dao;

import java.util.List;

import com.viru.pojo.Login;

public interface LoginDao {

	boolean addNewUser(Login l);
	
	Login checkUser(Login l);
	boolean updateBalance(String username,double amount);
	double getBalance(String username);
	List<Login> gellAllCustomer();
	boolean deleteCustomer(String username);
	boolean approveUser(String username);
    boolean blockUser(String username);
    boolean unblockUser(String username);
    
}
