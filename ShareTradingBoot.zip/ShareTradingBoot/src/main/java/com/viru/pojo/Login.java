package com.viru.pojo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "login")
public class Login {

	@Id
	private String username;
	private String password;
	private String role;
	private String email;
	private double balance;
	private boolean approved;
	private boolean blocked;

	public boolean isApproved(){ return approved; }
	public void setApproved(boolean approved){ this.approved = approved; }

	public boolean isBlocked(){ return blocked; }
	public void setBlocked(boolean blocked){ this.blocked = blocked; }

	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Login(String username, String password, String role, String email, double balance) {
		super();
		this.username = username;
		this.password = password;
		this.role = role;
		this.email = email;
		this.balance = balance;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
