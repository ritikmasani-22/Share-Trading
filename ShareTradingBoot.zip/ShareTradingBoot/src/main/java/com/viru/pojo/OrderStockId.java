package com.viru.pojo;

import java.io.Serializable;
import java.util.Objects;

public class OrderStockId implements Serializable {
    
    // Fields must match the primary key fields in the OrderStock Entity
    private String username; 
    private Integer stockid;

    public OrderStockId() {}

    // Getters, Setters, hashCode, and equals MUST be implemented
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public Integer getStockid() { return stockid; }
    public void setStockid(Integer stockid) { this.stockid = stockid; }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderStockId that = (OrderStockId) o;
        return Objects.equals(stockid, that.stockid) && Objects.equals(username, that.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(stockid, username);
    }
}