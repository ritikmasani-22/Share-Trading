package com.viru.pojo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stocks")
public class Stocks {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int stockid;
	private int stockseize;
	private String stockname;
	private double stockprice;
	private String username;
	private double avgBuyPrice;
	
	public Stocks() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Stocks(int stockid, int stockseize, String stockname, double stockprice, String username,
			double avgBuyPrice) {
		super();
		this.stockid = stockid;
		this.stockseize = stockseize;
		this.stockname = stockname;
		this.stockprice = stockprice;
		this.username = username;
		this.avgBuyPrice = avgBuyPrice;
	}


	public int getStockid() {
		return stockid;
	}
	public void setStockid(int stockid) {
		this.stockid = stockid;
	}
	
	public int getStockseize() {
		return stockseize;
	}



	public void setStockseize(int stockseize) {
		this.stockseize = stockseize;
	}


	public String getStockname() {
		return stockname;
	}
	public void setStockname(String stockname) {
		this.stockname = stockname;
	}
	public double getStockprice() {
		return stockprice;
	}
	public void setStockprice(double stockprice) {
		this.stockprice = stockprice;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}


	public double getAvgBuyPrice() {
		return avgBuyPrice;
	}


	public void setAvgBuyPrice(double avgBuyPrice) {
		this.avgBuyPrice = avgBuyPrice;
	}
	
	
	

}
