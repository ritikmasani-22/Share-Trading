package com.viru.pojo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "orderstocks")
@IdClass(OrderStockId.class) // Necessary to handle composite key
public class OrderStock {

    // Primary Key Fields (Must match OrderStockId field names)
    @Id
    private String username; 
    
    @Id
    private Integer stockid; 
    
    private String stockname;
    
    @Column(name = "seize")
    private int quantity; 
    
    @Column(name = "stockprice")
    private double currentStockPrice; 

    @Column(name = "avg_buy_price")
    private double avgBuyPrice;

    // Getters and Setters (omitted)
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public Integer getStockid() { return stockid; }
    public void setStockid(Integer stockid) { this.stockid = stockid; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
	public String getStockname() {
		return stockname;
	}
	public void setStockname(String stockname) {
		this.stockname = stockname;
	}
	public double getCurrentStockPrice() {
		return currentStockPrice;
	}
	public void setCurrentStockPrice(double currentStockPrice) {
		this.currentStockPrice = currentStockPrice;
	}
	public double getAvgBuyPrice() {
		return avgBuyPrice;
	}
	public void setAvgBuyPrice(double avgBuyPrice) {
		this.avgBuyPrice = avgBuyPrice;
	}
    
}