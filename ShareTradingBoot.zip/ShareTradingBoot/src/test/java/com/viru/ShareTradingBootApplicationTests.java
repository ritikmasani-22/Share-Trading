package com.viru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShareTradingBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
